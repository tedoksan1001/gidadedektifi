# Gıda Dedektifi (Food Detective)

Bu uygulama, gıda israfını önlemek ve evdeki malzemeleri en iyi şekilde değerlendirmek için tasarlanmıştır.

## Özellikler

- **Barkod Okuyucu**: Ürünlerin barkodunu tarayarak sisteme kaydeder. Son kullanma tarihine (SKT) 2 gün kala otomatik bildirim gönderir.
- **Artan Yemek Tarifi**: Evde kalan malzemeleri seçerek, bu malzemelerle yapılabilecek tarifleri bulmanızı sağlar.
- **eTwinning Katkısı**: Farklı ülkelerden kullanıcıların kendi geleneksel "artan yemekleri değerlendirme" tariflerini paylaştığı ortak bir platform.
- **Firebase Firestore**: Tüm veriler Firebase üzerinde güvenli ve gerçek zamanlı olarak depolanır.

## Kurulum ve Çalıştırma

### Gereksinimler
- Flutter SDK
- Android Studio / VS Code
- Firebase Projesi

### Adımlar
1. Bu depoyu klonlayın.
2. `flutter pub get` komutu ile bağımlılıkları yükleyin.
3. Firebase konsolundan bir Android uygulaması ekleyin ve `google-services.json` dosyasını `android/app/` dizinine yerleştirin.
4. (Opsiyonel) `lib/main.dart` içindeki `FirebaseOptions` kısmını kendi projenize göre güncelleyin.
5. `flutter run` ile uygulamayı başlatın.

## Kullanılan Teknolojiler
- **Flutter**: Mobil uygulama geliştirme.
- **Firebase Firestore**: Veritabanı.
- **Mobile Scanner**: Barkod okuma.
- **Flutter Local Notifications**: Hatırlatıcı bildirimler.
- **Provider**: Durum yönetimi (State Management).

## eTwinning
Bu proje, okullar arası işbirliğini teşvik eden eTwinning kapsamında geliştirilmiştir. Farklı kültürlerin mutfak sırlarını keşfederek gıda israfına küresel bir çözüm bulmayı hedefler.
