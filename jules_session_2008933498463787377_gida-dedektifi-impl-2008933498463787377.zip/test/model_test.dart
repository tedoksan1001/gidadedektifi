import 'package:flutter_test/flutter_test.dart';
import 'package:gida_dedektifi/models/product.dart';

void main() {
  group('Product Model Tests', () {
    test('Product toMap and fromMap works correctly', () {
      final date = DateTime(2025, 12, 31);
      final product = Product(
        id: '123',
        name: 'Elma',
        barcode: '111222333',
        expirationDate: date,
      );

      final map = product.toMap();
      expect(map['name'], 'Elma');
      expect(map['barcode'], '111222333');
      expect(map['expirationDate'], date.toIso8601String());

      final fromMap = Product.fromMap('123', map);
      expect(fromMap.name, product.name);
      expect(fromMap.barcode, product.barcode);
      expect(fromMap.expirationDate, product.expirationDate);
    });
  });
}
