import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../models/recipe.dart';

class ETwinningScreen extends StatelessWidget {
  const ETwinningScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firebaseService = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('eTwinning Katkısı')),
      body: StreamBuilder<List<Recipe>>(
        stream: firebaseService.getRecipes(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Henüz katkı yapılmamış. İlk tarifi siz ekleyin!'));
          }

          final recipes = snapshot.data!;

          return ListView.builder(
            itemCount: recipes.length,
            itemBuilder: (context, index) {
              final recipe = recipes[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: ListTile(
                  leading: const Icon(Icons.public, color: Colors.purple),
                  title: Text(recipe.title),
                  subtitle: Text('Ülke: ${recipe.country}'),
                  onTap: () => _showRecipeDetails(context, recipe),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddRecipeDialog(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showRecipeDetails(BuildContext context, Recipe recipe) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        builder: (_, scrollController) => SingleChildScrollView(
          controller: scrollController,
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(recipe.title, style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 8),
                Text('Ülke: ${recipe.country}', style: const TextStyle(fontStyle: FontStyle.italic)),
                const Divider(),
                const Text('Malzemeler:', style: TextStyle(fontWeight: FontWeight.bold)),
                ...recipe.ingredients.map((i) => Text('• $i')),
                const SizedBox(height: 16),
                const Text('Hazırlanışı:', style: TextStyle(fontWeight: FontWeight.bold)),
                Text(recipe.instructions),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showAddRecipeDialog(BuildContext context) {
    final titleController = TextEditingController();
    final ingredientsController = TextEditingController();
    final instructionsController = TextEditingController();
    final countryController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Geleneksel Tarif Ekle'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: titleController, decoration: const InputDecoration(labelText: 'Tarif Başlığı')),
              TextField(controller: countryController, decoration: const InputDecoration(labelText: 'Ülke')),
              TextField(controller: ingredientsController, decoration: const InputDecoration(labelText: 'Malzemeler (Virgülle ayırın)')),
              TextField(
                controller: instructionsController,
                decoration: const InputDecoration(labelText: 'Hazırlanışı'),
                maxLines: 3,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
          ElevatedButton(
            onPressed: () async {
              if (titleController.text.isNotEmpty) {
                final recipe = Recipe(
                  id: '',
                  title: titleController.text,
                  country: countryController.text,
                  ingredients: ingredientsController.text.split(',').map((e) => e.trim()).toList(),
                  instructions: instructionsController.text,
                );
                final service = context.read<FirebaseService>();
                await service.addRecipe(recipe);
                if (context.mounted) Navigator.pop(context);
              }
            },
            child: const Text('Paylaş'),
          ),
        ],
      ),
    );
  }
}
