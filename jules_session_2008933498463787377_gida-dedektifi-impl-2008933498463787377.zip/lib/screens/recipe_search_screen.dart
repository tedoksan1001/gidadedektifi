import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../models/recipe.dart';

class RecipeSearchScreen extends StatefulWidget {
  const RecipeSearchScreen({super.key});

  @override
  State<RecipeSearchScreen> createState() => _RecipeSearchScreenState();
}

class _RecipeSearchScreenState extends State<RecipeSearchScreen> {
  final List<String> _selectedIngredients = [];
  final TextEditingController _ingredientController = TextEditingController();
  List<Recipe> _foundRecipes = [];
  bool _isLoading = false;

  void _searchRecipes() async {
    if (_selectedIngredients.isEmpty) return;
    
    setState(() => _isLoading = true);
    final service = context.read<FirebaseService>();
    final recipes = await service.getRecipesByIngredients(_selectedIngredients);
    if (!mounted) return;
    setState(() {
      _foundRecipes = recipes;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Artan Yemek Tarifi')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ingredientController,
                    decoration: const InputDecoration(
                      hintText: 'Malzeme ekle (örn: bayat ekmek)',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (value) {
                      if (value.isNotEmpty) {
                        setState(() {
                          _selectedIngredients.add(value);
                          _ingredientController.clear();
                        });
                      }
                    },
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () {
                    if (_ingredientController.text.isNotEmpty) {
                      setState(() {
                        _selectedIngredients.add(_ingredientController.text);
                        _ingredientController.clear();
                      });
                    }
                  },
                  child: const Icon(Icons.add),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: _selectedIngredients.map((ingredient) => Chip(
                label: Text(ingredient),
                onDeleted: () => setState(() => _selectedIngredients.remove(ingredient)),
              )).toList(),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _selectedIngredients.isEmpty ? null : _searchRecipes,
              icon: const Icon(Icons.search),
              label: const Text('Tarif Bul'),
              style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
            ),
            const Divider(height: 32),
            Expanded(
              child: _isLoading 
                ? const Center(child: CircularProgressIndicator())
                : _foundRecipes.isEmpty
                  ? const Center(child: Text('Malzemelerinize uygun tarif bulunamadı.'))
                  : ListView.builder(
                      itemCount: _foundRecipes.length,
                      itemBuilder: (context, index) {
                        final recipe = _foundRecipes[index];
                        return Card(
                          child: ListTile(
                            title: Text(recipe.title),
                            subtitle: Text(recipe.ingredients.join(', ')),
                            onTap: () => _showRecipeDetails(recipe),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRecipeDetails(Recipe recipe) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        builder: (_, scrollController) => SingleChildScrollView(
          controller: scrollController,
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(recipe.title, style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 8),
                Text('Ülke: ${recipe.country}', style: const TextStyle(fontStyle: FontStyle.italic)),
                const Divider(),
                const Text('Malzemeler:', style: TextStyle(fontWeight: FontWeight.bold)),
                ...recipe.ingredients.map((i) => Text('• $i')),
                const SizedBox(height: 16),
                const Text('Hazırlanışı:', style: TextStyle(fontWeight: FontWeight.bold)),
                Text(recipe.instructions),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
