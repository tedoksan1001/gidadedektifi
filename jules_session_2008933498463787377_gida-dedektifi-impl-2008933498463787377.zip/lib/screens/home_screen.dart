import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../services/data_seeder.dart';
import 'barcode_scanner_screen.dart';
import 'recipe_search_screen.dart';
import 'etwinning_screen.dart';
import 'inventory_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gıda Dedektifi'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_backup_restore),
            tooltip: 'Örnek Veri Yükle',
            onPressed: () async {
              // Simple way to seed data for demo
              final service = Provider.of<FirebaseService>(context, listen: false);
              await DataSeeder.seedRecipes(service);
              if (!context.mounted) return;
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Örnek veriler yüklendi!')),
                );
              }
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            _buildMenuCard(
              context,
              'Barkod Okuyucu',
              Icons.qr_code_scanner,
              Colors.blue,
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BarcodeScannerScreen())),
            ),
            _buildMenuCard(
              context,
              'Envanterim',
              Icons.inventory,
              Colors.orange,
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InventoryScreen())),
            ),
            _buildMenuCard(
              context,
              'Artan Yemek Tarifi',
              Icons.restaurant_menu,
              Colors.green,
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RecipeSearchScreen())),
            ),
            _buildMenuCard(
              context,
              'eTwinning Katkısı',
              Icons.public,
              Colors.purple,
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ETwinningScreen())),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuCard(BuildContext context, String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: color),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
