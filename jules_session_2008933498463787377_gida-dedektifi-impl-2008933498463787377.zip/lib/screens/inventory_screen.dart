import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/firebase_service.dart';
import '../models/product.dart';

class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firebaseService = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Envanterim')),
      body: StreamBuilder<List<Product>>(
        stream: firebaseService.getProducts(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Henüz ürün eklenmemiş.'));
          }

          final products = snapshot.data!;
          // Sort by expiration date
          products.sort((a, b) => a.expirationDate.compareTo(b.expirationDate));

          return ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              final isExpiringSoon = product.expirationDate.difference(DateTime.now()).inDays <= 2;

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                color: isExpiringSoon ? Colors.red.shade50 : null,
                child: ListTile(
                  title: Text(product.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('Barkod: ${product.barcode}'),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text('SKT', style: TextStyle(fontSize: 12, color: Colors.grey)),
                      Text(
                        DateFormat('dd.MM.yyyy').format(product.expirationDate),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: isExpiringSoon ? Colors.red : Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
