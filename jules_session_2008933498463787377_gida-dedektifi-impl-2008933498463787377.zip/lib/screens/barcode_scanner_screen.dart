import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../services/notification_service.dart';
import '../models/product.dart';

class BarcodeScannerScreen extends StatefulWidget {
  const BarcodeScannerScreen({super.key});

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen> {
  bool _isScanned = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ürün Barkodu Oku')),
      body: MobileScanner(
        onDetect: (capture) {
          final List<Barcode> barcodes = capture.barcodes;
          if (barcodes.isNotEmpty && !_isScanned) {
            _isScanned = true;
            final String code = barcodes.first.rawValue ?? "Unknown";
            _showAddProductDialog(context, code);
          }
        },
      ),
    );
  }

  void _showAddProductDialog(BuildContext context, String barcode) {
    final nameController = TextEditingController();
    DateTime selectedDate = DateTime.now().add(const Duration(days: 7));

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Ürün Bilgileri'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Barkod: $barcode'),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Ürün Adı'),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Text('SKT: '),
                  TextButton(
                    onPressed: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: selectedDate,
                        firstDate: DateTime.now(),
                        lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
                      );
                      if (picked != null) {
                        setState(() => selectedDate = picked);
                      }
                    },
                    child: Text("${selectedDate.toLocal()}".split(' ')[0]),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                setState(() => _isScanned = false);
              },
              child: const Text('İptal'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (nameController.text.isNotEmpty) {
                  final product = Product(
                    id: '',
                    name: nameController.text,
                    barcode: barcode,
                    expirationDate: selectedDate,
                  );
                  final firebaseService = context.read<FirebaseService>();
                  final notificationService = context.read<NotificationService>();
                  
                  await firebaseService.addProduct(product);
                  await notificationService.scheduleExpirationNotification(product.name, product.expirationDate);
                  
                  if (mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Ürün başarıyla kaydedildi!')),
                    );
                    Navigator.pop(context);
                  }
                }
              },
              child: const Text('Kaydet'),
            ),
          ],
        ),
      ),
    );
  }
}
