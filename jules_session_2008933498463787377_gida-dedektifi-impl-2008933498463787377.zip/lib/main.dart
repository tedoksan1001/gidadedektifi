import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'screens/home_screen.dart';
import 'services/firebase_service.dart';
import 'services/notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Note: For a real app, you would use the google-services.json file.
  // Here we use the provided API key for programmatic initialization.
  // IMPORTANT: Replace the placeholders below with your actual Firebase project values.
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: 'AIzaSyABTomIDlkfHmW_YrL0a5vpbnxNxeed3jg',
        appId: '1:YOUR_APP_ID:android:YOUR_APP_HASH', // TODO: Replace with real App ID
        messagingSenderId: 'YOUR_SENDER_ID', // TODO: Replace with real Sender ID
        projectId: 'gida-dedektifi', // TODO: Replace with real Project ID
        storageBucket: 'gida-dedektifi.appspot.com', // TODO: Replace with real Bucket
      ),
    );
  } catch (e) {
    debugPrint('Firebase initialization failed: $e');
  }

  final notificationService = NotificationService();
  await notificationService.initNotification();

  runApp(
    MultiProvider(
      providers: [
        Provider<FirebaseService>(create: (_) => FirebaseService()),
        Provider<NotificationService>(create: (_) => notificationService),
      ],
      child: const GidaDedektifiApp(),
    ),
  );
}

class GidaDedektifiApp extends StatelessWidget {
  const GidaDedektifiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gıda Dedektifi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green, brightness: Brightness.light),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
