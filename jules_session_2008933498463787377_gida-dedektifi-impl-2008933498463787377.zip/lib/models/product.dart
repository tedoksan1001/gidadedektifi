class Product {
  final String id;
  final String name;
  final String barcode;
  final DateTime expirationDate;

  Product({
    required this.id,
    required this.name,
    required this.barcode,
    required this.expirationDate,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'barcode': barcode,
      'expirationDate': expirationDate.toIso8601String(),
    };
  }

  factory Product.fromMap(String id, Map<String, dynamic> map) {
    return Product(
      id: id,
      name: map['name'] ?? '',
      barcode: map['barcode'] ?? '',
      expirationDate: DateTime.parse(map['expirationDate']),
    );
  }
}
