import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';
import '../models/recipe.dart';

class FirebaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Products
  Future<void> addProduct(Product product) {
    return _db.collection('products').add(product.toMap());
  }

  Stream<List<Product>> getProducts() {
    return _db.collection('products').snapshots().map((snapshot) =>
        snapshot.docs.map((doc) => Product.fromMap(doc.id, doc.data())).toList());
  }

  // Recipes
  Future<void> addRecipe(Recipe recipe) {
    return _db.collection('recipes').add(recipe.toMap());
  }

  Stream<List<Recipe>> getRecipes() {
    return _db.collection('recipes').snapshots().map((snapshot) =>
        snapshot.docs.map((doc) => Recipe.fromMap(doc.id, doc.data())).toList());
  }

  Future<List<Recipe>> getRecipesByIngredients(List<String> ingredients) async {
    // Basic implementation: fetch all and filter client-side
    // In a real app with many recipes, you'd use more advanced querying or Algolia
    QuerySnapshot snapshot = await _db.collection('recipes').get();
    List<Recipe> allRecipes = snapshot.docs
        .map((doc) => Recipe.fromMap(doc.id, doc.data() as Map<String, dynamic>))
        .toList();

    return allRecipes.where((recipe) {
      return recipe.ingredients.any((ingredient) =>
          ingredients.any((userIngredient) =>
              ingredient.toLowerCase().contains(userIngredient.toLowerCase())));
    }).toList();
  }
}
