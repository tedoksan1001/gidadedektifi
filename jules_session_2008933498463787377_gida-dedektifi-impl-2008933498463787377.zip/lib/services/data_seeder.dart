import '../models/recipe.dart';
import 'firebase_service.dart';

class DataSeeder {
  static Future<void> seedRecipes(FirebaseService service) async {
    final recipes = [
      Recipe(
        id: '',
        title: 'Bayat Ekmek Köftesi',
        country: 'Türkiye',
        ingredients: ['bayat ekmek', 'yumurta', 'maydanoz', 'peynir', 'baharat'],
        instructions: 'Ekmekleri ıslatıp sıkın. Diğer malzemelerle yoğurup kızartın.',
      ),
      Recipe(
        id: '',
        title: 'Pain Perdu (Kayıp Ekmek)',
        country: 'Fransa',
        ingredients: ['bayat ekmek', 'süt', 'yumurta', 'şeker', 'tereyağı'],
        instructions: 'Ekmekleri sütlü karışıma bulayıp tavada kızartın.',
      ),
      Recipe(
        id: '',
        title: 'Ribollita',
        country: 'İtalya',
        ingredients: ['fasulye', 'bayat ekmek', 'lahana', 'sebze suyu'],
        instructions: 'Sebzeleri haşlayın, içine ekmekleri ekleyip yoğunlaşana kadar pişirin.',
      ),
    ];

    for (var recipe in recipes) {
      await service.addRecipe(recipe);
    }
  }
}
