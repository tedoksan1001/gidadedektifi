package com.gidadedektifi.gida_dedektifi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
